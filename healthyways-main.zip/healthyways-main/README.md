# healthyways
An online food ordering web application for home-cooked meals

![Demo](https://imgur.com/J1ZK4yp.png)

## Running development server

To run the Node.js backend and React.js frontend simultaneously, run the `npm run dev` script.
