const EditFoodPage = () => {
  return (
    <div>
      <h1>Edit Food lmao</h1>
    </div>
  );
};

export default EditFoodPage;
